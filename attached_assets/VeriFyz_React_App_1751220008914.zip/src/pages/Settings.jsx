import React from "react";

const Settings = () => {
  return (
    <div className="page settings">
      <h2>Settings</h2>
      <p>Customize your VeriFyz experience here (QR/NFC preference, notifications, etc).</p>
    </div>
  );
};

export default Settings;
