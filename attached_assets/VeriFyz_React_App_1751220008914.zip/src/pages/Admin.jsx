import React from "react";

const Admin = () => {
  return (
    <div className="page admin">
      <h2>Admin Panel</h2>
      <p>Review presale submissions, analytics, and site controls.</p>
    </div>
  );
};

export default Admin;
