import React from "react";

const Dashboard = () => {
  return (
    <div className="page dashboard">
      <h2>Your Dashboard</h2>
      <p>Presence logs, scans, and upcoming rewards will appear here.</p>
    </div>
  );
};

export default Dashboard;
